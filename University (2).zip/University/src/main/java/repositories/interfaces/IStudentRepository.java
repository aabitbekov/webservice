package repositories.interfaces;

import domain.Students;
import domain.UserLoginData;

public interface IStudentRepository extends IEntityRepository<Students>{
    Students getStudentsByID(long id);

    static Students findStudentsByLogin(UserLoginData data);

    static Students getStudentsByUsername(String username);
}
