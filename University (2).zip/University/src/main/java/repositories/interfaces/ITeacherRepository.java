package repositories.interfaces;
import domain.Teachers;
import domain.UserLoginData;

public interface ITeacherRepository extends IEntityRepository<Teachers> {
    Teachers getTeachersByID(long id);

    static Teachers findTeachersByLogin(UserLoginData data);

    static Teachers getTeachersByUsername(String username);
    }

