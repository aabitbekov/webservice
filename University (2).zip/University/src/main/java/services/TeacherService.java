package services;
import domain.Teachers;
import domain.UserLoginData;
import repositories.TeacherRepository;
import repositories.interfaces.ITeacherRepository;
import services.intefaces.ITeachersService;

public class TeacherService implements ITeachersService {
    private ITeacherRepository Repo = new TeacherRepository();

    @Override
    public Teachers getTeachersByID(long id) {
        return Repo.getTeachersByID(id);
    }

    @Override
    public Teachers findTeachersByLogin(UserLoginData data) {
        return null;
    }

    @Override
    public Teachers getTeachersByUsername(String username) {
        return ITeacherRepository.getTeachersByUsername(username);

    }
}
