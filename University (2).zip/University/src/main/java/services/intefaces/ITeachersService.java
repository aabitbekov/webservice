package services.intefaces;

import domain.Teachers;
import domain.UserLoginData;

public interface ITeachersService {
    Teachers getTeachersByID(long id);

    Teachers findTeachersByLogin(UserLoginData data);

    Teachers getTeachersByUsername(String username);
}