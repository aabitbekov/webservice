package services.intefaces;

import domain.Students;
import domain.UserLoginData;

public interface IStudentService {

    Students getStudentsByID(long id);

    Students findStudentsByLogin(UserLoginData data);

    Students getStudentsByUsername(String username);
}
